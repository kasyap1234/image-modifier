package models

import "time"

type ImageConfig struct {
	Config MinioConfig `json:"config"`
}


package app 

func InitApp(){
	
}